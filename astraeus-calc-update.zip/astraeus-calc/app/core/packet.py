"""Orchestrator: request dict -> validated chart packet dict.

Pipeline: resolve location -> local->UTC->JD -> natal bodies/houses/aspects ->
derived analysis -> (optional transit snapshot) -> validation -> meta.
"""
import hashlib
import json
from datetime import datetime, timezone

from . import config
from . import geo, timeutil, ephemeris, aspects, analysis, transits, validate, progressions
from .settings import CALC_VERSION, SETTINGS_VERSION


class InputError(ValueError):
    pass


def _resolve_location(birth: dict):
    if birth.get("latitude") is not None and birth.get("longitude") is not None and birth.get("timezone"):
        return float(birth["latitude"]), float(birth["longitude"]), birth["timezone"], birth.get("place_label")
    hit = geo.resolve(birth.get("city") or birth.get("place_label"))
    if hit:
        lat, lon, tz = hit
        return lat, lon, tz, (birth.get("place_label") or birth.get("city"))
    raise InputError(
        "Could not resolve location. Provide latitude+longitude+timezone, "
        "or a city present in the geo table (e.g. 'Belgrade, Serbia')."
    )


def _input_hash(req: dict) -> str:
    blob = json.dumps(req, sort_keys=True, default=str).encode()
    return "sha256:" + hashlib.sha256(blob).hexdigest()[:32]


def build_packet(req: dict) -> dict:
    birth = req["birth"]
    settings = req.get("settings") or {}
    zodiac = settings.get("zodiac", "tropical")
    house_system = settings.get("house_system", "placidus")
    node_type = settings.get("node_type", "true")
    include_points = settings.get("include_points", ["chiron", "lilith"])
    time_accuracy = birth.get("time_accuracy", "exact")

    lat, lon, tz, label = _resolve_location(birth)
    local_iso, utc_iso, offset, dst, jd = timeutil.to_utc_and_jd(
        birth["date"], birth["time"], tz)

    # --- natal ---
    bodies = ephemeris.compute_bodies(jd, zodiac, node_type, include_points)
    houses, angles, cusp_lons = ephemeris.compute_houses(jd, lat, lon, house_system, zodiac)
    analysis.assign_houses(bodies, cusp_lons)

    asc_point = {"name": "ASC", "lon": angles["asc"]["lon"], "speed": None}
    mc_point = {"name": "MC", "lon": angles["mc"]["lon"], "speed": None}
    aspect_targets = {**bodies, "ASC": asc_point, "MC": mc_point}
    natal_aspects = aspects.detect(aspect_targets, include_minors=False)

    el, mo = analysis.balances(bodies)
    phase_name, phase_angle = analysis.lunar_phase(bodies["Sun"]["lon"], bodies["Moon"]["lon"])

    natal_complete = (
        all(p in bodies for p in ["Sun", "Moon", "Mercury", "Venus", "Mars",
                                   "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"])
        and len(houses) == 12 and "asc" in angles and "mc" in angles
        and len(natal_aspects) >= 0
    )

    natal = {
        "chart_ruler": analysis.chart_ruler(angles["asc"]["lon"]),
        "planets": list(bodies.values()),
        "angles": angles,
        "houses": houses,
        "aspects": natal_aspects,
        "element_balance": el,
        "modality_balance": mo,
        "lunar_phase": {"name": phase_name, "sun_moon_angle": phase_angle},
        "retrogrades": analysis.retrogrades(bodies),
    }

    # --- optional transit snapshot ---
    transit_block = None
    transit_requested = bool(req.get("transit"))
    transit_complete = False
    if transit_requested:
        t = req["transit"]
        _, t_utc, _, _, t_jd = timeutil.to_utc_and_jd(
            t["date"], t.get("time", "12:00:00"), t.get("timezone", "UTC"))
        tb = transits.transit_bodies(t_jd, zodiac)
        natal_for_transit = {**{k: {"name": k, "lon": v["lon"]} for k, v in bodies.items()},
                             "ASC": {"name": "ASC", "lon": angles["asc"]["lon"]},
                             "MC": {"name": "MC", "lon": angles["mc"]["lon"]}}
        t2n = transits.transit_to_natal(tb, natal_for_transit)
        from .transits import ORB_POLICY
        transit_complete = len(tb) > 0
        transit_block = {
            "moment_utc": t_utc,
            "orb_policy": ORB_POLICY,
            "planets": list(tb.values()),
            "aspects_to_natal": t2n,
        }

    # --- optional progressions (secondary + solar arc) ---
    prog_block = None
    prog_requested = bool(req.get("progressions"))
    prog_complete = False
    if prog_requested:
        p = req["progressions"]
        target_date = p["date"]  # the calendar date to progress TO, e.g. "2026-07-15"

        natal_for_directed = {**{k: {"name": k, "lon": v["lon"]} for k, v in bodies.items()},
                              "ASC": {"name": "ASC", "lon": angles["asc"]["lon"]},
                              "MC": {"name": "MC", "lon": angles["mc"]["lon"]}}

        sec_jd, sec_bodies, sec_angles, sec_houses = progressions.secondary_positions(
            jd, target_date, birth["date"], zodiac, lat, lon, house_system)
        sec_directed = {**{k: {"name": k, "lon": v["lon"]} for k, v in sec_bodies.items()},
                        "ASC": {"name": "ASC", "lon": sec_angles["asc"]["lon"]},
                        "MC": {"name": "MC", "lon": sec_angles["mc"]["lon"]}}
        sec_aspects = progressions.directed_to_natal(sec_directed, natal_for_directed, "secondary")

        # solar arc: the arc the progressed Sun has moved since birth
        arc = (sec_bodies["Sun"]["lon"] - bodies["Sun"]["lon"]) % 360
        sa_bodies, sa_angles = progressions.solar_arc_positions(bodies, angles, arc)
        sa_directed = {**{k: {"name": k, "lon": v["lon"]} for k, v in sa_bodies.items()},
                      "ASC": {"name": "ASC", "lon": sa_angles["asc"]["lon"]},
                      "MC": {"name": "MC", "lon": sa_angles["mc"]["lon"]}}
        sa_aspects = progressions.directed_to_natal(sa_directed, natal_for_directed, "solar_arc")

        prog_complete = bool(sec_bodies) and bool(sa_bodies)
        prog_block = {
            "target_date": target_date,
            "secondary": {
                "method": "day_for_a_year; angles via progressed JD through natal coordinates "
                          "(conventional fast method, not real progressed GMT)",
                "progressed_julian_day_ut": round(sec_jd, 7),
                "planets": list(sec_bodies.values()),
                "angles": sec_angles,
                "houses": sec_houses,
                "aspects_to_natal": sec_aspects,
            },
            "solar_arc": {
                "method": "every natal point shifted by the secondary-progressed Sun's arc; "
                          "directed positions only, no houses of their own",
                "arc_degrees": round(arc, 6),
                "directed_planets": list(sa_bodies.values()),
                "directed_angles": sa_angles,
                "aspects_to_natal": sa_aspects,
            },
        }

    forecast_requested = bool((req.get("forecast") or {}).get("enabled"))

    vflags = validate.build(natal_complete, time_accuracy,
                            transit_requested, transit_complete, forecast_requested)
    if prog_requested:
        vflags["progressions_validated"] = prog_complete
        if not prog_complete:
            vflags["reasons"].append("progressions requested but failed to compute")
            vflags["validated_for_interpretation"] = False

    warnings = []
    if config.EPHE_MODE == "moshier":
        warnings.append("Moshier model in use: reduced precision and Chiron unavailable. "
                        "Run scripts/fetch_ephe.py for full Swiss-Ephemeris accuracy.")
    if time_accuracy == "approx":
        warnings.append("Birth time marked approximate: ASC, MC, houses and Moon degree may shift.")
    if prog_requested:
        warnings.append("Progressed angles (MC/ASC) use the conventional fast method "
                        "(progressed JD through natal coordinates), not 'real' progressed GMT. "
                        "Most progressed-planet aspects are unaffected; only progressed-angle "
                        "house/aspect precision differs slightly between conventions.")
    if forecast_requested:
        warnings.append("Forecast requested but not implemented in this build (Phase 3).")

    return {
        "meta": {
            "calc_version": CALC_VERSION,
            "settings_version": SETTINGS_VERSION,
            "ephemeris": config.EPHE_MODE,
            "tzdata_version": timeutil.tzdata_version(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "input_hash": _input_hash(req),
        },
        "validation": vflags,
        "birth": {
            "local": local_iso, "utc": utc_iso, "utc_offset": offset, "dst_active": dst,
            "julian_day_ut": round(jd, 7),
            "latitude": lat, "longitude": lon, "timezone": tz, "place_label": label,
        },
        "settings": {"zodiac": zodiac, "house_system": house_system, "node_type": node_type},
        "natal": natal,
        "transits": transit_block,
        "progressions": prog_block,
        "forecast": None,
        "warnings": warnings,
    }
