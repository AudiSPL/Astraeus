"""Request schema. The response is returned as the packet dict (its schema is
documented in README); keeping it untyped avoids over-constraining the contract
while the packet grows through the phases.
"""
from typing import Literal, Optional
from pydantic import BaseModel, Field


class BirthIn(BaseModel):
    date: str = Field(..., examples=["1984-07-24"])
    time: str = Field(..., examples=["05:10:00"])
    time_accuracy: Literal["exact", "approx", "unknown"] = "exact"
    place_label: Optional[str] = Field(None, examples=["Belgrade, Serbia"])
    city: Optional[str] = None              # looked up in geo table
    latitude: Optional[float] = None        # explicit coords bypass the table
    longitude: Optional[float] = None
    timezone: Optional[str] = None          # IANA id, e.g. Europe/Belgrade


class SettingsIn(BaseModel):
    zodiac: Literal["tropical", "sidereal"] = "tropical"
    house_system: Literal["placidus", "whole_sign", "koch", "equal"] = "placidus"
    node_type: Literal["true", "mean"] = "true"
    include_points: list[str] = ["chiron", "lilith"]


class TransitIn(BaseModel):
    date: str
    time: str = "12:00:00"
    timezone: str = "UTC"


class ForecastIn(BaseModel):
    enabled: bool = False
    months: int = 12


class ProgressionsIn(BaseModel):
    date: str = Field(..., examples=["2026-07-15"])  # calendar date to progress TO


class ChartRequest(BaseModel):
    birth: BirthIn
    settings: SettingsIn = SettingsIn()
    transit: Optional[TransitIn] = None
    forecast: Optional[ForecastIn] = None
    progressions: Optional[ProgressionsIn] = None
