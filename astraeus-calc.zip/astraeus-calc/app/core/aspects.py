"""Natal aspect detection. Angles (ASC/MC) are included as targets; their
applying/separating is left null because an angle's longitude rate isn't a
simple body speed.
"""
from .settings import ASPECTS, MINOR_ASPECTS, ORB_BY_BODY, ASPECT_FACTOR


def separation(a: float, b: float) -> float:
    d = abs(a - b) % 360
    return d if d <= 180 else 360 - d


def _orb(name_a: str, name_b: str, aspect: str) -> float:
    base = max(ORB_BY_BODY.get(name_a, 3), ORB_BY_BODY.get(name_b, 3))
    return base * ASPECT_FACTOR[aspect]


def _applying(a, sa, b, sb, angle, dt=0.02):
    if sa is None or sb is None:
        return None
    now = abs(separation(a, b) - angle)
    nxt = abs(separation(a + sa * dt, b + sb * dt) - angle)
    return nxt < now


def detect(points: dict, include_minors: bool = False) -> list[dict]:
    """points: name -> {lon, speed (or None for angles), name}."""
    table = dict(ASPECTS)
    if include_minors:
        table.update(MINOR_ASPECTS)

    names = list(points)
    out = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            A, B = points[names[i]], points[names[j]]
            s = separation(A["lon"], B["lon"])
            for aspect, angle in table.items():
                orb = _orb(A["name"], B["name"], aspect)
                d = abs(s - angle)
                if d <= orb:
                    out.append({
                        "a": A["name"], "b": B["name"], "type": aspect,
                        "exact_deg": angle, "orb": round(d, 3),
                        "applying": _applying(A["lon"], A.get("speed"),
                                              B["lon"], B.get("speed"), angle),
                    })
    out.sort(key=lambda x: x["orb"])
    return out
