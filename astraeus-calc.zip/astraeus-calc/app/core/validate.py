"""Build the validation block. validated_for_interpretation is the single gate
the agent checks before saying anything.

This build implements natal + transit snapshot. Forecast is Phase 3: requesting
it is recorded as not-produced (a warning), and does NOT block natal/transit
interpretation in this build. Phase 3 will make forecast a hard gate.
"""


def build(natal_complete: bool, time_accuracy: str,
          transit_requested: bool, transit_complete: bool,
          forecast_requested: bool) -> dict:
    natal_validated = natal_complete and time_accuracy != "unknown"
    transits_validated = transit_requested and transit_complete

    reasons = []
    if not natal_validated:
        if time_accuracy == "unknown":
            reasons.append("birth time unknown: ASC, MC and houses are unreliable")
        else:
            reasons.append("natal computation incomplete")
    if transit_requested and not transits_validated:
        reasons.append("transit data missing")
    if forecast_requested:
        reasons.append("forecast not produced (Phase 3 feature) — natal/transit unaffected")

    master = natal_validated and (not transit_requested or transits_validated)

    return {
        "validated_for_interpretation": master,
        "natal_validated": natal_validated,
        "transits_validated": transits_validated,
        "forecast_validated": False,
        "reasons": reasons,
    }
