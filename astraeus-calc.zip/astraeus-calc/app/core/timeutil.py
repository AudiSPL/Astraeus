"""Convert local civil birth time to UTC and Julian Day (UT).

Uses zoneinfo + pinned tzdata so historical DST is correct (e.g. Belgrade in
July 1984 = CEST, +02:00). Always pass an IANA id, never a raw offset.
"""
from datetime import datetime
from zoneinfo import ZoneInfo
import importlib.metadata as _md

import swisseph as swe

UTC = ZoneInfo("UTC")


def _parse_time(t: str):
    parts = [int(x) for x in t.split(":")] + [0, 0]
    return parts[0], parts[1], parts[2]


def to_utc_and_jd(date: str, time: str, tz: str):
    """date 'YYYY-MM-DD', time 'HH:MM[:SS]', tz IANA id.

    Returns (local_iso, utc_iso, offset_str, dst_active, julian_day_ut).
    """
    y, m, d = (int(x) for x in date.split("-"))
    hh, mm, ss = _parse_time(time)
    local = datetime(y, m, d, hh, mm, ss, tzinfo=ZoneInfo(tz))
    utc = local.astimezone(UTC)

    offset = local.utcoffset()
    offset_str = _fmt_offset(offset)
    dst_active = bool(local.dst()) and local.dst().total_seconds() != 0

    jd = swe.julday(utc.year, utc.month, utc.day,
                    utc.hour + utc.minute / 60 + utc.second / 3600, swe.GREG_CAL)
    return local.isoformat(), utc.isoformat(), offset_str, dst_active, jd


def _fmt_offset(off):
    total = int(off.total_seconds())
    sign = "+" if total >= 0 else "-"
    total = abs(total)
    return f"{sign}{total // 3600:02d}:{(total % 3600) // 60:02d}"


def tzdata_version():
    try:
        return _md.version("tzdata")
    except Exception:
        return "system"
