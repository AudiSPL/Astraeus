"""Astraeus calculation API.

POST /v1/chart-packet  -> validated chart packet (natal always; transit snapshot
                          if `transit` provided)
GET  /v1/health
"""
from fastapi import FastAPI, Header, HTTPException

from .schemas import ChartRequest
from .core import config
from .core.packet import build_packet, InputError

app = FastAPI(title="Astraeus Calculation API", version="1.0.0")


def _check_auth(authorization: str | None):
    if not config.REQUIRE_AUTH:
        return
    if authorization != f"Bearer {config.API_KEY}":
        raise HTTPException(status_code=401, detail="invalid or missing API key")


@app.get("/v1/health")
def health():
    return {"ok": True, "ephemeris": config.EPHE_MODE}


@app.post("/v1/chart-packet")
def chart_packet(req: ChartRequest, authorization: str | None = Header(default=None)):
    _check_auth(authorization)
    try:
        return build_packet(req.model_dump())
    except InputError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:  # noqa: BLE001 - surface a clean error to the agent
        raise HTTPException(status_code=500, detail=f"calculation error: {e}")
