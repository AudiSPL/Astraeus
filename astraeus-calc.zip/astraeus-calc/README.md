# Astraeus — Calculation API

Deterministic natal + transit chart engine. FastAPI + Swiss Ephemeris. The
interpretation agent never calculates — it only consumes the validated packet
this service returns, and must refuse when `validated_for_interpretation` is
`false`.

This build covers **Phase 1 (natal)** + **transit snapshot**. Forecast,
solar-return, progressions and synastry are later phases (the transit module
already ships the tested root-finding utilities the forecast scanner will use).

## Run it (Cursor / local)

```bash
./run_local.sh
# or manually:
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python scripts/fetch_ephe.py        # downloads the .se1 data files (already bundled here)
uvicorn app.main:app --reload --port 8080
```

Then: `http://localhost:8080/docs` for the live OpenAPI UI.

Run the tests (they assert a chart verified against Swiss Ephemeris directly):

```bash
python -m pytest -q
```

## Accuracy

Full **Swiss Ephemeris** precision when the `.se1` data files are present in
`ephe/` (bundled). Without them the service auto-falls back to the **Moshier**
model — reduced precision, and **no Chiron** — and says so in `meta.ephemeris`
and `warnings`. For "as accurate as possible", keep the data files.

Birth-time matters: the default profile's Ascendant is 29°22' Cancer — about 3
minutes of clock error flips it to Leo. Set `birth.time_accuracy` honestly
(`exact` / `approx` / `unknown`); `unknown` blocks interpretation.

## Endpoints

```
GET  /v1/health
POST /v1/chart-packet
```

Auth is off by default. Set `ASTRAEUS_REQUIRE_AUTH=true` and `ASTRAEUS_API_KEY`
to require `Authorization: Bearer <key>`.

### Request

```jsonc
{
  "birth": {
    "date": "1984-07-24",          // required
    "time": "05:10:00",            // required (seconds optional)
    "time_accuracy": "exact",      // exact | approx | unknown
    "place_label": "Belgrade, Serbia",   // resolved via geo table, OR:
    "latitude": 44.80401,          // explicit coords bypass the table
    "longitude": 20.46513,
    "timezone": "Europe/Belgrade"  // IANA id (not a raw offset)
  },
  "settings": {                    // all optional
    "zodiac": "tropical",          // tropical | sidereal
    "house_system": "placidus",    // placidus | whole_sign | koch | equal
    "node_type": "true",           // true | mean
    "include_points": ["chiron", "lilith"]
  },
  "transit": {                     // omit for natal-only
    "date": "2026-06-19", "time": "12:00:00", "timezone": "Europe/London"
  }
}
```

Minimal request: just `birth.date`, `birth.time`, and a known city (defaults to
Belgrade-area handling). Everything else has sane defaults.

### Response (chart packet)

Top-level keys: `meta`, `validation`, `birth`, `settings`, `natal`,
`transits`, `forecast`, `warnings`.

- `validation.validated_for_interpretation` — the gate the agent checks.
- `validation.natal_validated` / `transits_validated` / `forecast_validated`
  with `reasons[]` when false.
- `natal` — `chart_ruler`, `planets[]` (lon, sign, deg_in_sign, speed,
  retrograde, house), `angles{asc,mc}`, `houses[]` (12 cusps), `aspects[]`
  (with orb + applying), `element_balance`, `modality_balance`, `lunar_phase`,
  `retrogrades[]`.
- `transits` — `moment_utc`, `planets[]`, `aspects_to_natal[]` (tight orbs,
  applying/separating). `null` if no transit requested.
- `meta` — `calc_version`, `settings_version`, `ephemeris`, `tzdata_version`,
  `generated_at`, `input_hash` (cache key). Same input + versions → same packet.

## Geo

`app/core/geo.py` is a small static city → (lat, lon, IANA tz) table (Belgrade
default, plus regional + a few international cities). No live geocoder, so the
calc stays deterministic. Add a city by appending one line, or pass explicit
`latitude`/`longitude`/`timezone` to skip the table.

## Deploy

Dockerized → Google Cloud Run (prod) or Render (simplest). `.se1` files are
baked into the image. Not Vercel (native binary + data files + read-only FS).

```bash
docker build -t astraeus-calc .
docker run -p 8080:8080 astraeus-calc
```

## Licensing

Swiss Ephemeris is AGPL-3.0 **or** a paid Astrodienst professional license.
**Private/personal use → AGPL is fine.** If this ever becomes public or
commercial, either open-source the service or buy the professional license.
(Not legal advice — verify with Astrodienst.)

## Layout

```
app/
  main.py            FastAPI app + endpoints
  schemas.py         request model
  core/
    config.py        ephemeris path/mode detection, auth
    geo.py           static city table
    timeutil.py      local -> UTC -> Julian Day
    ephemeris.py     Swiss Ephemeris wrapper (thread-safe)
    aspects.py       natal aspect detection
    analysis.py      houses/balances/ruler/lunar phase
    transits.py      transit snapshot + exact-hit/station utilities (Phase 3-ready)
    validate.py      validation flags
    packet.py        orchestrator
ephe/                .se1 data files
scripts/fetch_ephe.py
tests/               golden-master + property tests
```
