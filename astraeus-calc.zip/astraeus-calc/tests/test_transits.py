"""Transit snapshot + the root-finding utilities the forecast layer will reuse."""
import copy
import swisseph as swe

from app.core import ephemeris, transits
from tests.conftest import DEFAULT_PROFILE


def test_transit_snapshot_present(client):
    req = copy.deepcopy(DEFAULT_PROFILE)
    req["transit"] = {"date": "2026-06-19", "time": "12:00:00", "timezone": "Europe/London"}
    p = client.post("/v1/chart-packet", json=req).json()
    assert p["transits"] is not None
    assert len(p["transits"]["planets"]) >= 8
    assert p["validation"]["transits_validated"] is True
    assert p["validation"]["validated_for_interpretation"] is True
    for a in p["transits"]["aspects_to_natal"]:
        assert a["type"] in {"conjunction", "sextile", "square", "trine", "opposition"}
        assert "applying" in a


def test_forecast_request_warns_not_blocks(client):
    req = copy.deepcopy(DEFAULT_PROFILE)
    req["forecast"] = {"enabled": True, "months": 12}
    p = client.post("/v1/chart-packet", json=req).json()
    assert p["validation"]["forecast_validated"] is False
    assert p["validation"]["natal_validated"] is True  # natal still usable
    assert any("Forecast" in w or "forecast" in w for w in p["warnings"])


def test_exact_hits_solar_return():
    """Transiting Sun conjunct natal Sun must occur once per year, ~the birthday."""
    ephemeris.init()
    flag = ephemeris.base_flag("tropical")
    natal_sun_lon = 121.4006  # Leo 1 24'
    jd0 = swe.julday(2026, 1, 1, 0.0, swe.GREG_CAL)
    jd1 = swe.julday(2026, 12, 31, 0.0, swe.GREG_CAL)
    hits = transits.exact_hits(swe.SUN, natal_sun_lon, 0, flag, jd0, jd1, step=1.0)
    assert len(hits) == 1
    y, mo, d, _ = swe.revjul(hits[0], swe.GREG_CAL)
    assert mo == 7 and 22 <= d <= 25   # solar return ~ 23-24 July


def test_stations_jupiter_in_window():
    """Jupiter has at least one station in any ~13-month window."""
    ephemeris.init()
    flag = ephemeris.base_flag("tropical")
    jd0 = swe.julday(2026, 1, 1, 0.0, swe.GREG_CAL)
    jd1 = swe.julday(2027, 2, 1, 0.0, swe.GREG_CAL)
    st = transits.stations(swe.JUPITER, flag, jd0, jd1, step=2.0)
    assert len(st) >= 1
    assert st[0]["direction"] in {"retrograde", "direct"}
